"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { ArrowLeft, CalendarIcon, Clock, User, MapPin, Star } from "lucide-react"
import Link from "next/link"

// Telangana doctors database
const doctors = [
  {
    id: 1,
    name: "Dr. Rajesh Kumar",
    specialty: "Internal Medicine",
    hospital: "MGM Hospital",
    city: "Warangal",
    rating: 4.8,
    experience: "15 years",
    availableSlots: ["09:00", "10:30", "14:00", "15:30"],
    fee: "₹500",
  },
  {
    id: 2,
    name: "Dr. Priya Sharma",
    specialty: "Cardiology",
    hospital: "Rohini Super Speciality Hospital",
    city: "Warangal",
    rating: 4.9,
    experience: "12 years",
    availableSlots: ["08:30", "11:00", "13:30", "16:00"],
    fee: "₹800",
  },
  {
    id: 3,
    name: "Dr. Venkat Reddy",
    specialty: "Dermatology",
    hospital: "Lifeline Hospital",
    city: "Warangal",
    rating: 4.7,
    experience: "10 years",
    availableSlots: ["09:30", "11:30", "14:30", "16:30"],
    fee: "₹600",
  },
  {
    id: 4,
    name: "Dr. Lakshmi Devi",
    specialty: "Gynecology",
    hospital: "Jaya Hospital",
    city: "Warangal",
    rating: 4.6,
    experience: "14 years",
    availableSlots: ["10:00", "12:00", "15:00", "17:00"],
    fee: "₹700",
  },
  {
    id: 5,
    name: "Dr. Krishna Reddy",
    specialty: "Neurology",
    hospital: "Yashoda Hospital",
    city: "Hyderabad",
    rating: 4.9,
    experience: "20 years",
    availableSlots: ["09:00", "11:30", "14:30", "16:30"],
    fee: "₹1200",
  },
  {
    id: 6,
    name: "Dr. Sudha Rani",
    specialty: "Orthopedics",
    hospital: "KIMS Hospital",
    city: "Hyderabad",
    rating: 4.8,
    experience: "15 years",
    availableSlots: ["08:30", "10:30", "13:00", "15:30"],
    fee: "₹900",
  },
  {
    id: 7,
    name: "Dr. Srinivas",
    specialty: "Pediatrics",
    hospital: "Karimnagar Government Hospital",
    city: "Karimnagar",
    rating: 4.2,
    experience: "12 years",
    availableSlots: ["09:00", "11:00", "14:00", "16:00"],
    fee: "₹400",
  },
  {
    id: 8,
    name: "Dr. Rajendra Prasad",
    specialty: "General Surgery",
    hospital: "Nizamabad Government Hospital",
    city: "Nizamabad",
    rating: 4.0,
    experience: "18 years",
    availableSlots: ["08:00", "10:00", "13:00", "15:00"],
    fee: "₹600",
  },
]

export default function BookAppointment() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [selectedDoctor, setSelectedDoctor] = useState("")
  const [selectedTime, setSelectedTime] = useState("")
  const [appointmentType, setAppointmentType] = useState("")
  const [symptoms, setSymptoms] = useState("")
  const [patientName, setPatientName] = useState("")
  const [patientPhone, setPatientPhone] = useState("")
  const [patientDisease, setPatientDisease] = useState("")
  const [isBooking, setIsBooking] = useState(false)

  const handleBookAppointment = async () => {
    setIsBooking(true)

    // Simulate booking process
    await new Promise((resolve) => setTimeout(resolve, 2000))

    alert("Appointment booked successfully! You will receive a confirmation SMS shortly.")

    // Reset form
    setSelectedDoctor("")
    setSelectedTime("")
    setAppointmentType("")
    setSymptoms("")
    setPatientName("")
    setPatientPhone("")
    setPatientDisease("")
    setIsBooking(false)
  }

  const selectedDoctorData = doctors.find((doc) => doc.id.toString() === selectedDoctor)

  // Filter doctors based on disease (if entered)
  const getRecommendedDoctors = () => {
    if (!patientDisease.trim()) return doctors

    const disease = patientDisease.toLowerCase()

    // Simple disease-to-specialty mapping
    const diseaseSpecialtyMap: { [key: string]: string[] } = {
      heart: ["Cardiology"],
      skin: ["Dermatology"],
      bone: ["Orthopedics"],
      brain: ["Neurology"],
      child: ["Pediatrics"],
      women: ["Gynecology"],
      surgery: ["General Surgery"],
      fever: ["Internal Medicine"],
      headache: ["Neurology", "Internal Medicine"],
      chest: ["Cardiology", "Internal Medicine"],
      stomach: ["Internal Medicine"],
    }

    for (const [keyword, specialties] of Object.entries(diseaseSpecialtyMap)) {
      if (disease.includes(keyword)) {
        return doctors.filter((doc) => specialties.includes(doc.specialty))
      }
    }

    return doctors
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Book Appointment</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Appointment Form */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">Schedule Your Appointment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Patient Information */}
              <div className="space-y-4">
                <h3 className="font-medium text-gray-800">Patient Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input
                      placeholder="Enter patient name"
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      className="border-blue-200 focus:border-blue-400"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone Number</Label>
                    <Input
                      placeholder="Enter phone number"
                      value={patientPhone}
                      onChange={(e) => setPatientPhone(e.target.value)}
                      className="border-blue-200 focus:border-blue-400"
                    />
                  </div>
                </div>

                {/* Disease Name */}
                <div className="space-y-2">
                  <Label>Disease/Condition Name (Optional)</Label>
                  <Input
                    placeholder="Enter your disease or health condition"
                    value={patientDisease}
                    onChange={(e) => setPatientDisease(e.target.value)}
                    className="border-blue-200 focus:border-blue-400"
                  />
                  <p className="text-xs text-gray-500">
                    This helps us recommend the most suitable doctor for your condition
                  </p>
                </div>
              </div>

              {/* Doctor Selection */}
              <div className="space-y-2">
                <Label>Select Doctor</Label>
                <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue placeholder="Choose a doctor" />
                  </SelectTrigger>
                  <SelectContent>
                    {getRecommendedDoctors().map((doctor) => (
                      <SelectItem key={doctor.id} value={doctor.id.toString()}>
                        <div className="flex items-center space-x-2">
                          <div>
                            <p className="font-medium">{doctor.name}</p>
                            <p className="text-sm text-gray-600">
                              {doctor.specialty} - {doctor.hospital}, {doctor.city}
                            </p>
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {patientDisease && (
                  <p className="text-xs text-green-600">✓ Showing doctors recommended for "{patientDisease}"</p>
                )}
              </div>

              {/* Appointment Type */}
              <div className="space-y-2">
                <Label>Appointment Type</Label>
                <Select value={appointmentType} onValueChange={setAppointmentType}>
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue placeholder="Select appointment type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="consultation">General Consultation</SelectItem>
                    <SelectItem value="followup">Follow-up Visit</SelectItem>
                    <SelectItem value="checkup">Regular Checkup</SelectItem>
                    <SelectItem value="emergency">Emergency Consultation</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Time Slot Selection */}
              {selectedDoctorData && (
                <div className="space-y-2">
                  <Label>Available Time Slots</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {selectedDoctorData.availableSlots.map((time) => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                        className={
                          selectedTime === time ? "bg-blue-600 hover:bg-blue-700" : "border-blue-200 hover:bg-blue-50"
                        }
                      >
                        <Clock className="w-3 h-3 mr-1" />
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Symptoms/Reason */}
              <div className="space-y-2">
                <Label>Reason for Visit / Symptoms</Label>
                <Textarea
                  placeholder="Describe your symptoms or reason for the appointment..."
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  className="min-h-[100px] border-blue-200 focus:border-blue-400"
                />
              </div>

              <Button
                onClick={handleBookAppointment}
                disabled={!selectedDoctor || !selectedTime || !patientName || !patientPhone || isBooking}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
              >
                {isBooking ? "Booking..." : "Book Appointment"}
              </Button>
            </CardContent>
          </Card>

          {/* Calendar and Doctor Info */}
          <div className="space-y-6">
            {/* Calendar */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-blue-900 flex items-center">
                  <CalendarIcon className="w-5 h-5 mr-2" />
                  Select Date
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={(date) => date < new Date()}
                  className="rounded-md border border-blue-200"
                />
              </CardContent>
            </Card>

            {/* Selected Doctor Info */}
            {selectedDoctorData && (
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-blue-900">Doctor Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800">{selectedDoctorData.name}</h3>
                      <p className="text-sm text-blue-600">{selectedDoctorData.specialty}</p>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span>
                        {selectedDoctorData.hospital}, {selectedDoctorData.city}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span>{selectedDoctorData.rating} rating</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>{selectedDoctorData.experience} experience</span>
                    </div>
                  </div>

                  <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-700">Consultation Fee:</span>
                      <span className="font-medium text-blue-900">{selectedDoctorData.fee}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Recommended Doctors based on Disease */}
            {patientDisease && (
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-blue-900">Recommended for "{patientDisease}"</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {getRecommendedDoctors()
                      .slice(0, 3)
                      .map((doctor) => (
                        <div key={doctor.id} className="bg-green-50 rounded-lg p-3 border border-green-200">
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-medium text-gray-800">{doctor.name}</p>
                              <p className="text-sm text-green-700">{doctor.specialty}</p>
                              <p className="text-xs text-gray-600">{doctor.city}</p>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => setSelectedDoctor(doctor.id.toString())}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Select
                            </Button>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Upcoming Appointments */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900">Your Upcoming Appointments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-gray-800">Dr. Rajesh Kumar</h3>
                    <p className="text-sm text-blue-600">Internal Medicine - MGM Hospital, Warangal</p>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <CalendarIcon className="w-3 h-3" />
                        <span>Jan 25, 2024</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>10:30 AM</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="border-blue-200">
                      Reschedule
                    </Button>
                    <Button size="sm" variant="outline" className="border-red-200 text-red-600">
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
