"use client"

import { Card, CardContent } from "@/components/ui/card"
import {
  Stethoscope,
  MapPin,
  Calendar,
  Upload,
  Bell,
  Phone,
  Lightbulb,
  FileText,
  Heart,
  MessageCircle,
  Activity,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"

const features = [
  {
    icon: Stethoscope,
    title: "Symptom Checker",
    description: "Text, voice, or image input",
    color: "from-blue-500 to-blue-600",
    hoverColor: "hover:shadow-blue-500/25",
    route: "/symptom-checker",
  },
  {
    icon: MapPin,
    title: "Nearby Hospitals",
    description: "Uses GPS location",
    color: "from-green-500 to-green-600",
    hoverColor: "hover:shadow-green-500/25",
    route: "/nearby-hospitals",
  },
  {
    icon: Calendar,
    title: "Book Appointment",
    description: "Schedule with doctors",
    color: "from-purple-500 to-purple-600",
    hoverColor: "hover:shadow-purple-500/25",
    route: "/book-appointment",
  },
  {
    icon: Upload,
    title: "Upload Reports",
    description: "Camera/gallery upload",
    color: "from-orange-500 to-orange-600",
    hoverColor: "hover:shadow-orange-500/25",
    route: "/upload-reports",
  },
  {
    icon: Bell,
    title: "Medicine Reminder",
    description: "Set time, name, sound",
    color: "from-red-500 to-red-600",
    hoverColor: "hover:shadow-red-500/25",
    route: "/medicine-reminder",
  },
  {
    icon: Phone,
    title: "Emergency Contacts",
    description: "SOS contact, share location",
    color: "from-pink-500 to-pink-600",
    hoverColor: "hover:shadow-pink-500/25",
    route: "/emergency-contacts",
  },
  {
    icon: Lightbulb,
    title: "Health Tips",
    description: "Daily fitness & diet advice",
    color: "from-yellow-500 to-yellow-600",
    hoverColor: "hover:shadow-yellow-500/25",
    route: "/health-tips",
  },
  {
    icon: FileText,
    title: "Health Records",
    description: "Store test results, diseases",
    color: "from-indigo-500 to-indigo-600",
    hoverColor: "hover:shadow-indigo-500/25",
    route: "/health-records",
  },
  {
    icon: Heart,
    title: "Mental Health Support",
    description: "Mood tracker, meditation",
    color: "from-rose-500 to-rose-600",
    hoverColor: "hover:shadow-rose-500/25",
    route: "/mental-health",
  },
  {
    icon: MessageCircle,
    title: "AI Chatbot",
    description: "I Am There for You",
    color: "from-cyan-500 to-cyan-600",
    hoverColor: "hover:shadow-cyan-500/25",
    route: "/ai-chatbot",
  },
  {
    icon: Activity,
    title: "Fitness Tracker",
    description: "Steps, calories, activity",
    color: "from-emerald-500 to-emerald-600",
    hoverColor: "hover:shadow-emerald-500/25",
    route: "/fitness-tracker",
  },
  {
    icon: MessageSquare,
    title: "Feedback",
    description: "Rate app, report issues",
    color: "from-violet-500 to-violet-600",
    hoverColor: "hover:shadow-violet-500/25",
    route: "/feedback",
  },
]

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-blue-900 mb-2">Smart AI Diagnosis Assistant Dashboard</h1>
            <p className="text-xl text-blue-700">
              Welcome to Smart AI Diagnosis Assistant Dashboard, <span className="font-semibold">John Doe</span>!
            </p>
          </div>
        </div>
      </div>

      {/* Dashboard Grid */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Link key={index} href={feature.route}>
              <Card
                className={`group cursor-pointer transition-all duration-500 hover:scale-105 hover:shadow-2xl ${feature.hoverColor} border-0 bg-white/90 backdrop-blur-sm animate-[fadeInUp_0.6s_ease-out] hover:animate-[bounce_0.6s_ease-in-out]`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6 text-center space-y-4">
                  {/* 3D Icon */}
                  <div className="relative mx-auto w-16 h-16 mb-4">
                    <div
                      className={`absolute inset-0 bg-gradient-to-r ${feature.color} rounded-2xl transform rotate-6 group-hover:rotate-12 transition-transform duration-300`}
                    ></div>
                    <div
                      className={`relative bg-gradient-to-r ${feature.color} rounded-2xl p-4 transform -rotate-6 group-hover:rotate-0 transition-transform duration-300 shadow-lg`}
                    >
                      <feature.icon className="w-8 h-8 text-white mx-auto" />
                    </div>
                    {/* Glow effect */}
                    <div
                      className={`absolute inset-0 bg-gradient-to-r ${feature.color} rounded-2xl blur-xl opacity-0 group-hover:opacity-30 transition-opacity duration-300 -z-10`}
                    ></div>
                  </div>

                  {/* Title and Description */}
                  <div className="space-y-2">
                    <h3 className="font-bold text-lg text-gray-800 group-hover:text-blue-900 transition-colors duration-300">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-gray-600 group-hover:text-gray-700 transition-colors duration-300">
                      {feature.description}
                    </p>
                  </div>

                  {/* Hover glow border */}
                  <div className="absolute inset-0 rounded-lg border-2 border-transparent group-hover:border-blue-200 transition-colors duration-300"></div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white/50 backdrop-blur-sm border-t border-blue-100 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center">
          <p className="text-gray-600">Your health is our priority. Get personalized AI-powered health insights.</p>
        </div>
      </div>
    </div>
  )
}
