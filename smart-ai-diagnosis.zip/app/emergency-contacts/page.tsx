"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Phone, MapPin, Plus, Trash2, AlertTriangle, Share, Users } from "lucide-react"
import Link from "next/link"

interface EmergencyContact {
  id: number
  name: string
  relationship: string
  phone: string
  email?: string
  isPrimary: boolean
}

const emergencyServices = [
  { name: "Emergency Services", number: "911", description: "Police, Fire, Medical Emergency" },
  { name: "Poison Control", number: "1-800-222-1222", description: "24/7 Poison Emergency" },
  { name: "Crisis Hotline", number: "988", description: "Suicide & Crisis Lifeline" },
  { name: "Non-Emergency Police", number: "311", description: "Non-urgent police matters" },
]

export default function EmergencyContacts() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([
    {
      id: 1,
      name: "John Smith",
      relationship: "Spouse",
      phone: "+1 (555) 123-4567",
      email: "john.smith@email.com",
      isPrimary: true,
    },
    {
      id: 2,
      name: "Mary Johnson",
      relationship: "Mother",
      phone: "+1 (555) 234-5678",
      email: "mary.johnson@email.com",
      isPrimary: false,
    },
  ])

  const [newContact, setNewContact] = useState({
    name: "",
    relationship: "",
    phone: "",
    email: "",
  })

  const [currentLocation, setCurrentLocation] = useState<string>("Getting location...")
  const [isSharing, setIsSharing] = useState(false)

  const addContact = () => {
    if (newContact.name && newContact.phone && newContact.relationship) {
      const contact: EmergencyContact = {
        id: Date.now(),
        ...newContact,
        isPrimary: contacts.length === 0,
      }
      setContacts([...contacts, contact])
      setNewContact({ name: "", relationship: "", phone: "", email: "" })
    }
  }

  const deleteContact = (id: number) => {
    setContacts(contacts.filter((contact) => contact.id !== id))
  }

  const setPrimaryContact = (id: number) => {
    setContacts(
      contacts.map((contact) => ({
        ...contact,
        isPrimary: contact.id === id,
      })),
    )
  }

  const callContact = (phone: string) => {
    window.location.href = `tel:${phone}`
  }

  const shareLocation = async () => {
    setIsSharing(true)

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          const locationUrl = `https://maps.google.com/?q=${latitude},${longitude}`

          // Simulate sending location to emergency contacts
          const message = `Emergency Alert: I need help! My current location: ${locationUrl}`

          // In a real app, this would send SMS/email to all emergency contacts
          contacts.forEach((contact) => {
            console.log(`Sending to ${contact.name} (${contact.phone}): ${message}`)
          })

          alert(`Emergency alert sent to ${contacts.length} contacts with your location!`)
          setIsSharing(false)
        },
        (error) => {
          alert("Unable to get your location. Please enable location services.")
          setIsSharing(false)
        },
      )
    } else {
      alert("Geolocation is not supported by this browser.")
      setIsSharing(false)
    }
  }

  // Get current location on component mount
  useState(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation(
            `Lat: ${position.coords.latitude.toFixed(4)}, Lng: ${position.coords.longitude.toFixed(4)}`,
          )
        },
        () => {
          setCurrentLocation("Location access denied")
        },
      )
    }
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Emergency Contacts</h1>
        </div>

        {/* Emergency SOS Section */}
        <Card className="shadow-lg mb-6 bg-red-50 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-900 flex items-center">
              <AlertTriangle className="w-6 h-6 mr-2" />
              Emergency SOS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button
                size="lg"
                className="bg-red-600 hover:bg-red-700 text-white h-16"
                onClick={() => callContact("911")}
              >
                <Phone className="w-6 h-6 mr-2" />
                Call 911
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-red-300 text-red-700 hover:bg-red-50 h-16"
                onClick={shareLocation}
                disabled={isSharing}
              >
                <Share className="w-6 h-6 mr-2" />
                {isSharing ? "Sharing Location..." : "Share Location"}
              </Button>
            </div>
            <div className="mt-4 flex items-center space-x-2 text-sm text-gray-600">
              <MapPin className="w-4 h-4" />
              <span>Current Location: {currentLocation}</span>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Add New Contact */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <Plus className="w-5 h-5 mr-2" />
                Add Emergency Contact
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="contact-name">Full Name</Label>
                <Input
                  id="contact-name"
                  placeholder="Enter contact name"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div className="space-y-2">
                <Label>Relationship</Label>
                <Select
                  value={newContact.relationship}
                  onValueChange={(value) => setNewContact({ ...newContact, relationship: value })}
                >
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Spouse">Spouse</SelectItem>
                    <SelectItem value="Parent">Parent</SelectItem>
                    <SelectItem value="Child">Child</SelectItem>
                    <SelectItem value="Sibling">Sibling</SelectItem>
                    <SelectItem value="Friend">Friend</SelectItem>
                    <SelectItem value="Doctor">Doctor</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="contact-phone">Phone Number</Label>
                <Input
                  id="contact-phone"
                  placeholder="Enter phone number"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contact-email">Email (Optional)</Label>
                <Input
                  id="contact-email"
                  type="email"
                  placeholder="Enter email address"
                  value={newContact.email}
                  onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <Button
                onClick={addContact}
                disabled={!newContact.name || !newContact.phone || !newContact.relationship}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Contact
              </Button>
            </CardContent>
          </Card>

          {/* Emergency Services */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">Emergency Services</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {emergencyServices.map((service, index) => (
                  <div key={index} className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-blue-900">{service.name}</h3>
                        <p className="text-sm text-gray-600 mb-2">{service.description}</p>
                        <p className="text-lg font-bold text-blue-700">{service.number}</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => callContact(service.number)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Phone className="w-3 h-3 mr-1" />
                        Call
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Personal Emergency Contacts */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900 flex items-center">
              <Users className="w-5 h-5 mr-2" />
              Your Emergency Contacts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {contacts.map((contact) => (
                <div
                  key={contact.id}
                  className={`rounded-lg p-4 border ${
                    contact.isPrimary ? "bg-green-50 border-green-200" : "bg-white border-gray-200"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-semibold text-gray-800">{contact.name}</h3>
                        {contact.isPrimary && (
                          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                            Primary
                          </span>
                        )}
                      </div>
                      <div className="space-y-1 text-sm text-gray-600">
                        <p>Relationship: {contact.relationship}</p>
                        <div className="flex items-center space-x-2">
                          <Phone className="w-3 h-3" />
                          <span>{contact.phone}</span>
                        </div>
                        {contact.email && (
                          <div className="flex items-center space-x-2">
                            <span>📧</span>
                            <span>{contact.email}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        onClick={() => callContact(contact.phone)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Phone className="w-3 h-3 mr-1" />
                        Call
                      </Button>
                      {!contact.isPrimary && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setPrimaryContact(contact.id)}
                          className="border-blue-200 hover:bg-blue-50"
                        >
                          Set Primary
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteContact(contact.id)}
                        className="border-red-200 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}

              {contacts.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No emergency contacts added yet.</p>
                  <p className="text-sm mt-2">Add your first emergency contact above.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="shadow-lg mt-6 bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="space-y-2 text-sm text-yellow-800">
              <h3 className="font-bold">How Emergency Contacts Work:</h3>
              <ul className="list-disc list-inside space-y-1">
                <li>Tap "Share Location" to send your GPS coordinates to all emergency contacts</li>
                <li>Emergency contacts will receive SMS with your location and emergency alert</li>
                <li>Set a primary contact who will be called first in emergencies</li>
                <li>Keep contact information updated for reliable emergency response</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
