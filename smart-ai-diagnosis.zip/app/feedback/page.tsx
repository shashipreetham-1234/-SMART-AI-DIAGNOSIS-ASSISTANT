"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft, Star, Send, Bug, Lightbulb, MessageSquare, ThumbsUp } from "lucide-react"
import Link from "next/link"

interface FeedbackItem {
  id: number
  type: string
  rating?: number
  subject: string
  message: string
  date: string
  status: "submitted" | "in-review" | "resolved"
}

export default function Feedback() {
  const [feedbackType, setFeedbackType] = useState("")
  const [rating, setRating] = useState(0)
  const [subject, setSubject] = useState("")
  const [message, setMessage] = useState("")
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [previousFeedback] = useState<FeedbackItem[]>([
    {
      id: 1,
      type: "bug",
      subject: "App crashes when uploading large files",
      message: "The app crashes when I try to upload files larger than 5MB...",
      date: "2024-01-18",
      status: "in-review",
    },
    {
      id: 2,
      type: "suggestion",
      rating: 4,
      subject: "Add dark mode feature",
      message: "It would be great to have a dark mode option for better usability at night...",
      date: "2024-01-15",
      status: "submitted",
    },
  ])

  const submitFeedback = async () => {
    if (!feedbackType || !subject || !message) {
      alert("Please fill in all required fields")
      return
    }

    setIsSubmitting(true)

    // Simulate submission delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    alert("Thank you for your feedback! We'll review it and get back to you soon.")

    // Reset form
    setFeedbackType("")
    setRating(0)
    setSubject("")
    setMessage("")
    setEmail("")
    setIsSubmitting(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "submitted":
        return "bg-blue-100 text-blue-800"
      case "in-review":
        return "bg-yellow-100 text-yellow-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "bug":
        return <Bug className="w-4 h-4" />
      case "suggestion":
        return <Lightbulb className="w-4 h-4" />
      case "general":
        return <MessageSquare className="w-4 h-4" />
      default:
        return <MessageSquare className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Feedback & Support</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Feedback Form */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <MessageSquare className="w-5 h-5 mr-2" />
                Submit Feedback
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Feedback Type */}
              <div className="space-y-2">
                <Label>Feedback Type</Label>
                <Select value={feedbackType} onValueChange={setFeedbackType}>
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue placeholder="Select feedback type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bug">🐛 Bug Report</SelectItem>
                    <SelectItem value="suggestion">💡 Feature Suggestion</SelectItem>
                    <SelectItem value="general">💬 General Feedback</SelectItem>
                    <SelectItem value="compliment">👍 Compliment</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Rating (for general feedback and compliments) */}
              {(feedbackType === "general" || feedbackType === "compliment") && (
                <div className="space-y-2">
                  <Label>Rate your experience</Label>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(star)}
                        className={`p-1 transition-colors ${star <= rating ? "text-yellow-500" : "text-gray-300"}`}
                      >
                        <Star className="w-6 h-6 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Subject */}
              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="Brief description of your feedback"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              {/* Message */}
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Please provide detailed feedback..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="min-h-[120px] border-blue-200 focus:border-blue-400"
                />
              </div>

              {/* Email (optional) */}
              <div className="space-y-2">
                <Label htmlFor="email">Email (Optional)</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Your email for follow-up"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              {/* Priority (for bug reports) */}
              {feedbackType === "bug" && (
                <div className="space-y-2">
                  <Label>Priority Level</Label>
                  <RadioGroup defaultValue="medium" className="flex space-x-6">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="low" id="low" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="low" className="text-gray-700">
                        Low
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="medium" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="medium" className="text-gray-700">
                        Medium
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="high" id="high" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="high" className="text-gray-700">
                        High
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              )}

              <Button
                onClick={submitFeedback}
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
              >
                <Send className="w-4 h-4 mr-2" />
                {isSubmitting ? "Submitting..." : "Submit Feedback"}
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-3">
                <Button
                  variant="outline"
                  className="justify-start h-auto p-4 border-blue-200 hover:bg-blue-50"
                  onClick={() => {
                    setFeedbackType("bug")
                    setSubject("Bug Report")
                  }}
                >
                  <Bug className="w-5 h-5 mr-3 text-red-500" />
                  <div className="text-left">
                    <p className="font-medium">Report a Bug</p>
                    <p className="text-sm text-gray-600">Something not working correctly?</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="justify-start h-auto p-4 border-blue-200 hover:bg-blue-50"
                  onClick={() => {
                    setFeedbackType("suggestion")
                    setSubject("Feature Suggestion")
                  }}
                >
                  <Lightbulb className="w-5 h-5 mr-3 text-yellow-500" />
                  <div className="text-left">
                    <p className="font-medium">Suggest a Feature</p>
                    <p className="text-sm text-gray-600">Have an idea to improve the app?</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="justify-start h-auto p-4 border-blue-200 hover:bg-blue-50"
                  onClick={() => {
                    setFeedbackType("compliment")
                    setSubject("Positive Feedback")
                    setRating(5)
                  }}
                >
                  <ThumbsUp className="w-5 h-5 mr-3 text-green-500" />
                  <div className="text-left">
                    <p className="font-medium">Share Compliment</p>
                    <p className="text-sm text-gray-600">Love something about the app?</p>
                  </div>
                </Button>
              </div>

              {/* Contact Info */}
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200 mt-6">
                <h3 className="font-medium text-blue-900 mb-2">Need Immediate Help?</h3>
                <div className="space-y-2 text-sm text-blue-800">
                  <p>📧 Email: support@smartaidiagnosis.com</p>
                  <p>📞 Phone: +1 (555) 123-HELP</p>
                  <p>💬 Live Chat: Available 24/7</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Previous Feedback */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900">Your Previous Feedback</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {previousFeedback.map((item) => (
                <div key={item.id} className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-2">
                      {getTypeIcon(item.type)}
                      <h3 className="font-medium text-gray-800">{item.subject}</h3>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                        {item.status.replace("-", " ").toUpperCase()}
                      </span>
                      <span className="text-sm text-gray-500">{item.date}</span>
                    </div>
                  </div>
                  <p className="text-gray-700 text-sm mb-2">{item.message}</p>
                  {item.rating && (
                    <div className="flex items-center space-x-1">
                      <span className="text-sm text-gray-600">Rating:</span>
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < item.rating! ? "text-yellow-500 fill-current" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {previousFeedback.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No previous feedback submitted.</p>
                  <p className="text-sm mt-2">Your feedback history will appear here.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
