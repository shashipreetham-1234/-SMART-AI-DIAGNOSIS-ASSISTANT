"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Activity, Target, Flame, Footprints, Clock, TrendingUp } from "lucide-react"
import Link from "next/link"

interface FitnessData {
  steps: number
  calories: number
  distance: number
  activeMinutes: number
  heartRate: number
}

interface Goal {
  steps: number
  calories: number
  activeMinutes: number
}

export default function FitnessTracker() {
  const [todayData, setTodayData] = useState<FitnessData>({
    steps: 7842,
    calories: 342,
    distance: 5.2,
    activeMinutes: 45,
    heartRate: 72,
  })

  const [goals, setGoals] = useState<Goal>({
    steps: 10000,
    calories: 500,
    activeMinutes: 60,
  })

  const [isTracking, setIsTracking] = useState(false)
  const [workoutTimer, setWorkoutTimer] = useState(0)

  const weeklyData = [
    { day: "Mon", steps: 8500, calories: 380 },
    { day: "Tue", steps: 9200, calories: 420 },
    { day: "Wed", steps: 7800, calories: 350 },
    { day: "Thu", steps: 10500, calories: 480 },
    { day: "Fri", steps: 9800, calories: 450 },
    { day: "Sat", steps: 12000, calories: 550 },
    { day: "Sun", steps: 7842, calories: 342 },
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isTracking) {
      interval = setInterval(() => {
        setWorkoutTimer((prev) => prev + 1)
        // Simulate real-time data updates during workout
        setTodayData((prev) => ({
          ...prev,
          steps: prev.steps + Math.floor(Math.random() * 5),
          calories: prev.calories + Math.floor(Math.random() * 3),
          activeMinutes: prev.activeMinutes + (workoutTimer % 60 === 0 ? 1 : 0),
        }))
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isTracking, workoutTimer])

  const startWorkout = () => {
    setIsTracking(true)
    setWorkoutTimer(0)
  }

  const stopWorkout = () => {
    setIsTracking(false)
    alert(
      `Workout completed! Duration: ${Math.floor(workoutTimer / 60)}:${(workoutTimer % 60).toString().padStart(2, "0")}`,
    )
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getProgressPercentage = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Fitness Tracker</h1>
        </div>

        {/* Today's Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Footprints className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Steps</p>
                  <p className="text-2xl font-bold text-gray-800">{todayData.steps.toLocaleString()}</p>
                  <Progress value={getProgressPercentage(todayData.steps, goals.steps)} className="mt-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <Flame className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Calories</p>
                  <p className="text-2xl font-bold text-gray-800">{todayData.calories}</p>
                  <Progress value={getProgressPercentage(todayData.calories, goals.calories)} className="mt-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Clock className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Active Minutes</p>
                  <p className="text-2xl font-bold text-gray-800">{todayData.activeMinutes}</p>
                  <Progress
                    value={getProgressPercentage(todayData.activeMinutes, goals.activeMinutes)}
                    className="mt-2"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Activity className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Heart Rate</p>
                  <p className="text-2xl font-bold text-gray-800">{todayData.heartRate}</p>
                  <p className="text-xs text-gray-500">BPM</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Workout Tracker */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <Activity className="w-5 h-5 mr-2" />
                Workout Tracker
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-6xl font-bold text-blue-600 mb-2">{formatTime(workoutTimer)}</div>
                <p className="text-gray-600">Workout Duration</p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-sm text-gray-600">Distance</p>
                  <p className="text-xl font-bold text-blue-900">{todayData.distance} km</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-3">
                  <p className="text-sm text-gray-600">Calories</p>
                  <p className="text-xl font-bold text-orange-900">{todayData.calories}</p>
                </div>
              </div>

              <div className="space-y-2">
                {!isTracking ? (
                  <Button
                    onClick={startWorkout}
                    className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600"
                  >
                    Start Workout
                  </Button>
                ) : (
                  <Button
                    onClick={stopWorkout}
                    className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600"
                  >
                    Stop Workout
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Goals Setting */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Daily Goals
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Steps Goal</Label>
                <Input
                  type="number"
                  value={goals.steps}
                  onChange={(e) => setGoals({ ...goals, steps: Number.parseInt(e.target.value) || 0 })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div className="space-y-2">
                <Label>Calories Goal</Label>
                <Input
                  type="number"
                  value={goals.calories}
                  onChange={(e) => setGoals({ ...goals, calories: Number.parseInt(e.target.value) || 0 })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div className="space-y-2">
                <Label>Active Minutes Goal</Label>
                <Input
                  type="number"
                  value={goals.activeMinutes}
                  onChange={(e) => setGoals({ ...goals, activeMinutes: Number.parseInt(e.target.value) || 0 })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600">
                Update Goals
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Weekly Progress */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2" />
              Weekly Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2">
              {weeklyData.map((day, index) => (
                <div key={index} className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-2">{day.day}</p>
                  <div className="bg-blue-50 rounded-lg p-3 space-y-2">
                    <div>
                      <p className="text-xs text-gray-500">Steps</p>
                      <p className="text-sm font-bold text-blue-900">{day.steps.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Calories</p>
                      <p className="text-sm font-bold text-orange-900">{day.calories}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Health Insights */}
        <Card className="shadow-lg mt-6 bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-green-900">Health Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <p className="text-sm text-green-800">Great job! You're 78% towards your daily step goal.</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <p className="text-sm text-green-800">Your average heart rate is in the healthy range.</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <p className="text-sm text-green-800">
                  Try to increase your active minutes by 15 more to reach your goal.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
