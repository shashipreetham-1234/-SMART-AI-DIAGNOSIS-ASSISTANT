"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Heart, Apple, Dumbbell, Brain, Moon, Droplets, RefreshCw } from "lucide-react"
import Link from "next/link"

interface HealthTip {
  id: number
  title: string
  content: string
  category: string
  icon: any
  difficulty: "Easy" | "Medium" | "Hard"
  duration: string
  tags: string[]
}

const healthTipsDatabase: HealthTip[] = [
  {
    id: 1,
    title: "Start Your Day with Warm Water",
    content:
      "Drinking a glass of warm water first thing in the morning helps kickstart your metabolism, aids digestion, and helps flush out toxins from your body.",
    category: "Hydration",
    icon: Droplets,
    difficulty: "Easy",
    duration: "2 minutes",
    tags: ["morning", "detox", "metabolism"],
  },
  {
    id: 2,
    title: "Take a 10-Minute Walk After Meals",
    content:
      "A short walk after eating helps regulate blood sugar levels, improves digestion, and can reduce the risk of type 2 diabetes.",
    category: "Fitness",
    icon: Dumbbell,
    difficulty: "Easy",
    duration: "10 minutes",
    tags: ["diabetes", "digestion", "walking"],
  },
  {
    id: 3,
    title: "Practice Deep Breathing for Stress Relief",
    content:
      "Take 5 deep breaths: inhale for 4 counts, hold for 4, exhale for 6. This activates your parasympathetic nervous system and reduces stress hormones.",
    category: "Mental Health",
    icon: Brain,
    difficulty: "Easy",
    duration: "5 minutes",
    tags: ["stress", "anxiety", "breathing"],
  },
  {
    id: 4,
    title: "Eat a Rainbow of Vegetables",
    content:
      "Include vegetables of different colors in your meals. Each color provides different antioxidants and nutrients that support various body functions.",
    category: "Nutrition",
    icon: Apple,
    difficulty: "Medium",
    duration: "Daily",
    tags: ["antioxidants", "vitamins", "vegetables"],
  },
  {
    id: 5,
    title: "Follow the 20-20-20 Rule for Eye Health",
    content:
      "Every 20 minutes, look at something 20 feet away for 20 seconds. This helps reduce eye strain from screens and prevents digital eye fatigue.",
    category: "Eye Health",
    icon: Brain,
    difficulty: "Easy",
    duration: "20 seconds",
    tags: ["eye strain", "screen time", "vision"],
  },
  {
    id: 6,
    title: "Create a Consistent Sleep Schedule",
    content:
      "Go to bed and wake up at the same time every day, even on weekends. This helps regulate your circadian rhythm and improves sleep quality.",
    category: "Sleep",
    icon: Moon,
    difficulty: "Medium",
    duration: "7-9 hours",
    tags: ["sleep", "circadian rhythm", "rest"],
  },
  {
    id: 7,
    title: "Practice Gratitude Journaling",
    content:
      "Write down 3 things you're grateful for each day. This simple practice can improve mental health, reduce stress, and increase life satisfaction.",
    category: "Mental Health",
    icon: Heart,
    difficulty: "Easy",
    duration: "5 minutes",
    tags: ["gratitude", "mental health", "journaling"],
  },
  {
    id: 8,
    title: "Stay Hydrated Throughout the Day",
    content:
      "Aim for 8 glasses of water daily. Proper hydration supports kidney function, maintains energy levels, and keeps your skin healthy.",
    category: "Hydration",
    icon: Droplets,
    difficulty: "Easy",
    duration: "All day",
    tags: ["hydration", "energy", "skin health"],
  },
]

const categories = ["All", "Fitness", "Nutrition", "Mental Health", "Sleep", "Hydration", "Eye Health"]

export default function HealthTips() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [filteredTips, setFilteredTips] = useState(healthTipsDatabase)
  const [dailyTip, setDailyTip] = useState<HealthTip | null>(null)

  useEffect(() => {
    // Set daily tip (simulate personalization based on user profile)
    const today = new Date().getDate()
    const tipIndex = today % healthTipsDatabase.length
    setDailyTip(healthTipsDatabase[tipIndex])
  }, [])

  useEffect(() => {
    if (selectedCategory === "All") {
      setFilteredTips(healthTipsDatabase)
    } else {
      setFilteredTips(healthTipsDatabase.filter((tip) => tip.category === selectedCategory))
    }
  }, [selectedCategory])

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-green-100 text-green-800"
      case "Medium":
        return "bg-yellow-100 text-yellow-800"
      case "Hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Fitness":
        return Dumbbell
      case "Nutrition":
        return Apple
      case "Mental Health":
        return Brain
      case "Sleep":
        return Moon
      case "Hydration":
        return Droplets
      default:
        return Heart
    }
  }

  const refreshDailyTip = () => {
    const randomIndex = Math.floor(Math.random() * healthTipsDatabase.length)
    setDailyTip(healthTipsDatabase[randomIndex])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Daily Health Tips</h1>
        </div>

        {/* Daily Featured Tip */}
        {dailyTip && (
          <Card className="shadow-lg mb-6 bg-gradient-to-r from-blue-600 to-cyan-500 text-white">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center">
                  <Heart className="w-6 h-6 mr-2" />
                  Today's Featured Tip
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={refreshDailyTip} className="text-white hover:bg-white/20">
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <h3 className="text-xl font-semibold">{dailyTip.title}</h3>
                <p className="text-blue-50">{dailyTip.content}</p>
                <div className="flex items-center space-x-4">
                  <Badge variant="secondary" className="bg-white/20 text-white">
                    {dailyTip.category}
                  </Badge>
                  <Badge variant="secondary" className="bg-white/20 text-white">
                    {dailyTip.duration}
                  </Badge>
                  <Badge variant="secondary" className="bg-white/20 text-white">
                    {dailyTip.difficulty}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Category Filter */}
        <Card className="shadow-lg mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category ? "bg-blue-600 hover:bg-blue-700" : "border-blue-200 hover:bg-blue-50"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tips Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTips.map((tip) => {
            const IconComponent = getCategoryIcon(tip.category)
            return (
              <Card key={tip.id} className="shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-blue-900 text-lg leading-tight">{tip.title}</CardTitle>
                        <p className="text-sm text-gray-600">{tip.category}</p>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-700 text-sm leading-relaxed">{tip.content}</p>

                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      <Badge className={getDifficultyColor(tip.difficulty)}>{tip.difficulty}</Badge>
                      <Badge variant="outline" className="border-blue-200 text-blue-700">
                        {tip.duration}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {tip.tags.map((tag, index) => (
                      <span key={index} className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <Button
                    size="sm"
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                  >
                    Try This Tip
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Personalization Notice */}
        <Card className="shadow-lg mt-6 bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-yellow-800">
              <Brain className="w-5 h-5" />
              <p className="text-sm">
                <strong>Personalized Tips:</strong> These recommendations are based on your health profile. Complete
                your profile setup to get more targeted advice for your specific health goals.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
