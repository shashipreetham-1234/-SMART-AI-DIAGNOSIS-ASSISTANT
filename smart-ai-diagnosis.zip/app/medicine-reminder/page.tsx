"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Plus, Bell, Clock, Pill, Trash2 } from "lucide-react"
import Link from "next/link"

interface Reminder {
  id: number
  medicineName: string
  time: string
  frequency: string
  sound: string
}

export default function MedicineReminder() {
  const [reminders, setReminders] = useState<Reminder[]>([
    {
      id: 1,
      medicineName: "Vitamin D",
      time: "08:00",
      frequency: "Daily",
      sound: "Gentle Bell",
    },
    {
      id: 2,
      medicineName: "Blood Pressure Medication",
      time: "20:00",
      frequency: "Daily",
      sound: "Chime",
    },
  ])

  const [newReminder, setNewReminder] = useState({
    medicineName: "",
    time: "",
    frequency: "Daily",
    sound: "Gentle Bell",
  })

  const addReminder = () => {
    if (newReminder.medicineName && newReminder.time) {
      const reminder: Reminder = {
        id: Date.now(),
        ...newReminder,
      }
      setReminders([...reminders, reminder])
      setNewReminder({
        medicineName: "",
        time: "",
        frequency: "Daily",
        sound: "Gentle Bell",
      })
    }
  }

  const deleteReminder = (id: number) => {
    setReminders(reminders.filter((r) => r.id !== id))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Medicine Reminder</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Add New Reminder */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <Plus className="w-5 h-5 mr-2" />
                Add New Reminder
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="medicine-name">Medicine Name</Label>
                <Input
                  id="medicine-name"
                  placeholder="Enter medicine name"
                  value={newReminder.medicineName}
                  onChange={(e) => setNewReminder({ ...newReminder, medicineName: e.target.value })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="time">Time</Label>
                <Input
                  id="time"
                  type="time"
                  value={newReminder.time}
                  onChange={(e) => setNewReminder({ ...newReminder, time: e.target.value })}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div className="space-y-2">
                <Label>Frequency</Label>
                <Select
                  value={newReminder.frequency}
                  onValueChange={(value) => setNewReminder({ ...newReminder, frequency: value })}
                >
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Daily">Daily</SelectItem>
                    <SelectItem value="Twice Daily">Twice Daily</SelectItem>
                    <SelectItem value="Three Times Daily">Three Times Daily</SelectItem>
                    <SelectItem value="Weekly">Weekly</SelectItem>
                    <SelectItem value="As Needed">As Needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Reminder Sound</Label>
                <Select
                  value={newReminder.sound}
                  onValueChange={(value) => setNewReminder({ ...newReminder, sound: value })}
                >
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Gentle Bell">Gentle Bell</SelectItem>
                    <SelectItem value="Chime">Chime</SelectItem>
                    <SelectItem value="Beep">Beep</SelectItem>
                    <SelectItem value="Melody">Melody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={addReminder}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Reminder
              </Button>
            </CardContent>
          </Card>

          {/* Current Reminders */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                Active Reminders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reminders.map((reminder) => (
                  <div key={reminder.id} className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Pill className="w-4 h-4 text-blue-600" />
                          <h3 className="font-semibold text-blue-900">{reminder.medicineName}</h3>
                        </div>
                        <div className="space-y-1 text-sm text-gray-600">
                          <div className="flex items-center space-x-2">
                            <Clock className="w-3 h-3" />
                            <span>{reminder.time}</span>
                          </div>
                          <div>Frequency: {reminder.frequency}</div>
                          <div>Sound: {reminder.sound}</div>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteReminder(reminder.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                {reminders.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No reminders set yet. Add your first reminder!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
