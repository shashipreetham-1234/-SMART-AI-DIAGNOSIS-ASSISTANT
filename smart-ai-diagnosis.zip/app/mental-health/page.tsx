"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Heart, Brain, Sun, Music, BookOpen, Phone } from "lucide-react"
import Link from "next/link"

const moodOptions = [
  { value: "very-happy", label: "Very Happy", icon: "😄", color: "text-green-600" },
  { value: "happy", label: "Happy", icon: "😊", color: "text-green-500" },
  { value: "neutral", label: "Neutral", icon: "😐", color: "text-yellow-500" },
  { value: "sad", label: "Sad", icon: "😢", color: "text-orange-500" },
  { value: "very-sad", label: "Very Sad", icon: "😭", color: "text-red-500" },
  { value: "anxious", label: "Anxious", icon: "😰", color: "text-purple-500" },
  { value: "stressed", label: "Stressed", icon: "😤", color: "text-red-400" },
]

const activities = [
  {
    id: 1,
    title: "5-Minute Breathing Exercise",
    description: "Deep breathing to calm your mind and reduce anxiety",
    duration: "5 minutes",
    type: "breathing",
    icon: Brain,
    instructions: "Inhale for 4 counts, hold for 4, exhale for 6. Repeat 10 times.",
  },
  {
    id: 2,
    title: "Gratitude Journaling",
    description: "Write down three things you're grateful for today",
    duration: "10 minutes",
    type: "journaling",
    icon: BookOpen,
    instructions: "Think of 3 specific things that made you smile today and write them down.",
  },
  {
    id: 3,
    title: "Progressive Muscle Relaxation",
    description: "Tense and relax different muscle groups to release stress",
    duration: "15 minutes",
    type: "relaxation",
    icon: Heart,
    instructions: "Start with your toes, tense for 5 seconds, then relax. Move up through your body.",
  },
  {
    id: 4,
    title: "Mindful Walking",
    description: "Take a slow, mindful walk focusing on your surroundings",
    duration: "20 minutes",
    type: "movement",
    icon: Sun,
    instructions: "Walk slowly, notice 5 things you can see, 4 you can hear, 3 you can touch.",
  },
  {
    id: 5,
    title: "Calming Music Meditation",
    description: "Listen to soothing music while focusing on your breath",
    duration: "10 minutes",
    type: "meditation",
    icon: Music,
    instructions: "Sit comfortably, play calming music, and focus on your breathing rhythm.",
  },
]

const therapists = [
  {
    id: 1,
    name: "Dr. Sarah Williams",
    specialty: "Anxiety & Depression",
    rating: 4.9,
    experience: "12 years",
    availability: "Available Today",
    phone: "+1 (555) 123-4567",
  },
  {
    id: 2,
    name: "Dr. Michael Thompson",
    specialty: "Stress Management",
    rating: 4.8,
    experience: "15 years",
    availability: "Available Tomorrow",
    phone: "+1 (555) 234-5678",
  },
  {
    id: 3,
    name: "Dr. Emily Chen",
    specialty: "Mindfulness & CBT",
    rating: 4.7,
    experience: "10 years",
    availability: "Available This Week",
    phone: "+1 (555) 345-6789",
  },
]

export default function MentalHealthSupport() {
  const [currentMood, setCurrentMood] = useState("")
  const [journalEntry, setJournalEntry] = useState("")
  const [selectedActivity, setSelectedActivity] = useState<any>(null)
  const [moodHistory, setMoodHistory] = useState([
    { date: "2024-01-20", mood: "happy", note: "Had a great day at work" },
    { date: "2024-01-19", mood: "neutral", note: "Regular day, nothing special" },
    { date: "2024-01-18", mood: "sad", note: "Feeling a bit overwhelmed" },
  ])

  const saveMoodEntry = () => {
    if (currentMood) {
      const newEntry = {
        date: new Date().toISOString().split("T")[0],
        mood: currentMood,
        note: journalEntry,
      }
      setMoodHistory([newEntry, ...moodHistory])
      setCurrentMood("")
      setJournalEntry("")
    }
  }

  const getMoodEmoji = (mood: string) => {
    const moodOption = moodOptions.find((option) => option.value === mood)
    return moodOption ? moodOption.icon : "😐"
  }

  const getRecommendedActivities = () => {
    if (!currentMood) return activities.slice(0, 3)

    // Simple recommendation logic based on mood
    if (currentMood.includes("sad") || currentMood === "anxious") {
      return activities.filter((a) => a.type === "breathing" || a.type === "meditation" || a.type === "journaling")
    } else if (currentMood === "stressed") {
      return activities.filter((a) => a.type === "relaxation" || a.type === "movement")
    } else {
      return activities.slice(0, 3)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Mental Health Support</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Mood Tracker */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center">
                <Heart className="w-5 h-5 mr-2" />
                How are you feeling today?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Select your mood</label>
                <Select value={currentMood} onValueChange={setCurrentMood}>
                  <SelectTrigger className="border-blue-200 focus:border-blue-400">
                    <SelectValue placeholder="Choose your current mood" />
                  </SelectTrigger>
                  <SelectContent>
                    {moodOptions.map((mood) => (
                      <SelectItem key={mood.value} value={mood.value}>
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">{mood.icon}</span>
                          <span>{mood.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Journal Entry (Optional)</label>
                <Textarea
                  placeholder="What's on your mind? Write about your feelings..."
                  value={journalEntry}
                  onChange={(e) => setJournalEntry(e.target.value)}
                  className="min-h-[100px] border-blue-200 focus:border-blue-400"
                />
              </div>

              <Button
                onClick={saveMoodEntry}
                disabled={!currentMood}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
              >
                Save Mood Entry
              </Button>
            </CardContent>
          </Card>

          {/* Mood History */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">Your Mood History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {moodHistory.slice(0, 5).map((entry, index) => (
                  <div key={index} className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{getMoodEmoji(entry.mood)}</span>
                        <span className="font-medium text-gray-800 capitalize">{entry.mood.replace("-", " ")}</span>
                      </div>
                      <span className="text-sm text-gray-600">{entry.date}</span>
                    </div>
                    {entry.note && <p className="text-sm text-gray-700">{entry.note}</p>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recommended Activities */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900">Recommended Activities</CardTitle>
            <p className="text-gray-600">Based on your current mood</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getRecommendedActivities().map((activity) => (
                <div
                  key={activity.id}
                  className="bg-white rounded-lg p-4 border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => setSelectedActivity(activity)}
                >
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <activity.icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800">{activity.title}</h3>
                      <p className="text-sm text-gray-600">{activity.duration}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-700 mb-3">{activity.description}</p>
                  <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700">
                    Start Activity
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Activity Instructions Modal */}
        {selectedActivity && (
          <Card className="shadow-lg mt-6 bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-900 flex items-center">
                <selectedActivity.icon className="w-5 h-5 mr-2" />
                {selectedActivity.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-white rounded-lg p-4">
                <h4 className="font-medium text-gray-800 mb-2">Instructions:</h4>
                <p className="text-gray-700">{selectedActivity.instructions}</p>
              </div>
              <div className="flex space-x-3">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => {
                    // Simulate starting the activity
                    setTimeout(() => setSelectedActivity(null), 2000)
                  }}
                >
                  Start Now
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setSelectedActivity(null)}>
                  Maybe Later
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Professional Help */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900">Need Professional Support?</CardTitle>
            <p className="text-gray-600">Connect with licensed mental health professionals</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {therapists.map((therapist) => (
                <div key={therapist.id} className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="text-center mb-3">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Brain className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="font-medium text-gray-800">{therapist.name}</h3>
                    <p className="text-sm text-blue-600">{therapist.specialty}</p>
                  </div>
                  <div className="space-y-2 text-sm text-gray-600 mb-4">
                    <div className="flex justify-between">
                      <span>Rating:</span>
                      <span className="font-medium">⭐ {therapist.rating}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Experience:</span>
                      <span>{therapist.experience}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Availability:</span>
                      <span className="text-green-600">{therapist.availability}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700">
                      <Phone className="w-3 h-3 mr-1" />
                      Contact
                    </Button>
                    <Button size="sm" variant="outline" className="w-full">
                      View Profile
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Crisis Support */}
        <Card className="shadow-lg mt-6 bg-red-50 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6 text-red-600" />
              <div>
                <h3 className="font-bold text-red-900">Crisis Support</h3>
                <p className="text-sm text-red-800">
                  If you're having thoughts of self-harm, please reach out immediately:
                </p>
                <p className="text-sm text-red-800 font-medium">
                  National Suicide Prevention Lifeline: 988 | Crisis Text Line: Text HOME to 741741
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
