"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, MapPin, Phone, Clock, Star, Navigation, Search, Filter, AlertCircle } from "lucide-react"
import Link from "next/link"

// Telangana hospitals database with focus on Warangal
const hospitalsDatabase = [
  {
    id: 1,
    name: "MGM Hospital",
    address: "Mattewada, Warangal, Telangana 506007",
    distance: 1.2,
    rating: 4.3,
    phone: "+91 870 2577677",
    emergency: true,
    specialties: ["General Medicine", "Cardiology", "Neurology", "Orthopedics"],
    coordinates: { lat: 18.0005, lng: 79.5881 },
    doctors: ["Dr. Rajesh Kumar", "Dr. Priya Sharma"],
    diseases: ["fever", "heart disease", "stroke", "fractures"],
    city: "Warangal",
  },
  {
    id: 2,
    name: "Rohini Super Speciality Hospital",
    address: "Hanamkonda, Warangal, Telangana 506001",
    distance: 2.5,
    rating: 4.5,
    phone: "+91 870 2577123",
    emergency: true,
    specialties: ["Cardiology", "Gastroenterology", "Nephrology"],
    coordinates: { lat: 18.0056, lng: 79.594 },
    doctors: ["Dr. Venkat Reddy", "Dr. Srinivas Rao"],
    diseases: ["heart disease", "kidney disease", "liver problems"],
    city: "Warangal",
  },
  {
    id: 3,
    name: "Lifeline Hospital",
    address: "Hanamkonda, Warangal, Telangana 506001",
    distance: 3.1,
    rating: 4.2,
    phone: "+91 870 2577456",
    emergency: false,
    specialties: ["Pediatrics", "Gynecology", "General Surgery"],
    coordinates: { lat: 18.0103, lng: 79.5912 },
    doctors: ["Dr. Lakshmi Devi", "Dr. Ravi Teja"],
    diseases: ["child health", "women's health", "appendicitis"],
    city: "Warangal",
  },
  {
    id: 4,
    name: "Jaya Hospital",
    address: "Hanamkonda, Warangal, Telangana 506001",
    distance: 2.8,
    rating: 4.0,
    phone: "+91 870 2577789",
    emergency: true,
    specialties: ["Orthopedics", "Neurology", "General Medicine"],
    coordinates: { lat: 18.0089, lng: 79.5876 },
    doctors: ["Dr. Suresh Kumar", "Dr. Anand Rao"],
    diseases: ["fractures", "back pain", "headache", "fever"],
    city: "Warangal",
  },
  {
    id: 5,
    name: "Yashoda Hospital",
    address: "Somajiguda, Hyderabad, Telangana 500082",
    distance: 145.0,
    rating: 4.7,
    phone: "+91 40 23319999",
    emergency: true,
    specialties: ["Cardiology", "Neurology", "Oncology", "Transplant"],
    coordinates: { lat: 17.4256, lng: 78.4535 },
    doctors: ["Dr. Krishna Reddy", "Dr. Sudha Rani"],
    diseases: ["heart disease", "cancer", "brain tumor"],
    city: "Hyderabad",
  },
  {
    id: 6,
    name: "KIMS Hospital",
    address: "Minister Road, Secunderabad, Telangana 500003",
    distance: 142.0,
    rating: 4.6,
    phone: "+91 40 44885000",
    emergency: true,
    specialties: ["Cardiology", "Neurology", "Nephrology", "Orthopedics"],
    coordinates: { lat: 17.44, lng: 78.4983 },
    doctors: ["Dr. Ramesh Kumar", "Dr. Padma Rao"],
    diseases: ["heart disease", "kidney disease", "joint pain"],
    city: "Hyderabad",
  },
  {
    id: 7,
    name: "Sunshine Hospital",
    address: "Paradise Circle, Secunderabad, Telangana 500003",
    distance: 143.0,
    rating: 4.5,
    phone: "+91 40 44550000",
    emergency: true,
    specialties: ["Orthopedics", "Joint Replacement", "Sports Medicine"],
    coordinates: { lat: 17.4417, lng: 78.4983 },
    doctors: ["Dr. Gurava Reddy", "Dr. Sudhir Kumar"],
    diseases: ["fractures", "arthritis", "sports injuries"],
    city: "Hyderabad",
  },
  {
    id: 8,
    name: "Karimnagar Government Hospital",
    address: "Karimnagar, Telangana 505001",
    distance: 65.0,
    rating: 3.8,
    phone: "+91 878 2224979",
    emergency: true,
    specialties: ["General Medicine", "Pediatrics", "Obstetrics"],
    coordinates: { lat: 18.4386, lng: 79.1288 },
    doctors: ["Dr. Srinivas", "Dr. Kavitha"],
    diseases: ["fever", "child health", "pregnancy"],
    city: "Karimnagar",
  },
  {
    id: 9,
    name: "Nizamabad Government Hospital",
    address: "Nizamabad, Telangana 503001",
    distance: 120.0,
    rating: 3.7,
    phone: "+91 846 2224012",
    emergency: true,
    specialties: ["General Medicine", "Surgery", "Orthopedics"],
    coordinates: { lat: 18.6725, lng: 78.0941 },
    doctors: ["Dr. Rajendra Prasad", "Dr. Sunitha"],
    diseases: ["fever", "appendicitis", "fractures"],
    city: "Nizamabad",
  },
]

export default function NearbyHospitals() {
  const [location, setLocation] = useState<string>("Getting location...")
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [sortBy, setSortBy] = useState("distance")
  const [filteredHospitals, setFilteredHospitals] = useState(hospitalsDatabase)
  const [userCoordinates, setUserCoordinates] = useState<{ lat: number; lng: number } | null>(null)
  const [locationError, setLocationError] = useState<string | null>(null)
  const [cityFilter, setCityFilter] = useState("all")

  useEffect(() => {
    // Get user's location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setUserCoordinates({ lat: latitude, lng: longitude })

          // Calculate distances from user's location to each hospital
          const hospitalsWithDistance = hospitalsDatabase.map((hospital) => {
            const distance = calculateDistance(latitude, longitude, hospital.coordinates.lat, hospital.coordinates.lng)
            return { ...hospital, distance }
          })

          // Update hospitals with calculated distances
          setFilteredHospitals(hospitalsWithDistance)

          // Get city name from coordinates using reverse geocoding
          fetchCityFromCoordinates(latitude, longitude)
        },
        (error) => {
          console.error("Error getting location:", error)
          setLocationError("Unable to access your location. Please enable location services.")
          setLocation("Location access denied")
          // Default to Warangal coordinates
          const defaultLat = 18.0
          const defaultLng = 79.58
          setUserCoordinates({ lat: defaultLat, lng: defaultLng })
          setLocation("Default: Warangal, Telangana")
        },
        { enableHighAccuracy: true },
      )
    } else {
      setLocationError("Geolocation is not supported by this browser.")
      setLocation("Location not available")
    }
  }, [])

  // Function to calculate distance between two coordinates using Haversine formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371 // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1)
    const dLon = deg2rad(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const distance = R * c // Distance in km
    return Number.parseFloat(distance.toFixed(1))
  }

  const deg2rad = (deg: number) => {
    return deg * (Math.PI / 180)
  }

  const fetchCityFromCoordinates = async (latitude: number, longitude: number) => {
    try {
      // In a real app, you would use a geocoding service like Google Maps API
      // For this demo, we'll simulate it
      setLocation("Warangal, Telangana")
    } catch (error) {
      console.error("Error fetching city:", error)
      setLocation("Unknown location")
    }
  }

  useEffect(() => {
    let filtered = [...hospitalsDatabase]

    // Apply city filter
    if (cityFilter !== "all") {
      filtered = filtered.filter((hospital) => hospital.city === cityFilter)
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (hospital) =>
          hospital.name.toLowerCase().includes(query) ||
          hospital.specialties.some((spec) => spec.toLowerCase().includes(query)) ||
          hospital.doctors.some((doc) => doc.toLowerCase().includes(query)) ||
          hospital.diseases.some((disease) => disease.toLowerCase().includes(query)),
      )
    }

    // Apply type filter
    if (filterType !== "all") {
      switch (filterType) {
        case "emergency":
          filtered = filtered.filter((h) => h.emergency)
          break
        case "specialty":
          filtered = filtered.filter((h) => h.specialties.length > 2)
          break
        case "general":
          filtered = filtered.filter((h) => h.specialties.includes("General Medicine"))
          break
      }
    }

    // Apply sorting
    switch (sortBy) {
      case "distance":
        filtered.sort((a, b) => a.distance - b.distance)
        break
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "name":
        filtered.sort((a, b) => a.name.localeCompare(b.name))
        break
    }

    setFilteredHospitals(filtered)
  }, [searchQuery, filterType, sortBy, cityFilter])

  const getDirections = (hospital: any) => {
    if (userCoordinates) {
      const url = `https://www.google.com/maps/dir/?api=1&origin=${userCoordinates.lat},${userCoordinates.lng}&destination=${hospital.coordinates.lat},${hospital.coordinates.lng}`
      window.open(url, "_blank")
    } else {
      alert("Unable to get your location for directions.")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Nearby Hospitals</h1>
        </div>

        {/* Location Info */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-blue-700">
                <MapPin className="w-5 h-5" />
                <span className="font-medium">Your Location: {location}</span>
              </div>
              {locationError && (
                <div className="flex items-center space-x-2 text-red-600">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">{locationError}</span>
                </div>
              )}
              <Button
                size="sm"
                onClick={() => {
                  if (navigator.geolocation) {
                    setLocation("Updating location...")
                    navigator.geolocation.getCurrentPosition(
                      (position) => {
                        const { latitude, longitude } = position.coords
                        setUserCoordinates({ lat: latitude, lng: longitude })
                        fetchCityFromCoordinates(latitude, longitude)

                        // Recalculate distances
                        const hospitalsWithDistance = hospitalsDatabase.map((hospital) => {
                          const distance = calculateDistance(
                            latitude,
                            longitude,
                            hospital.coordinates.lat,
                            hospital.coordinates.lng,
                          )
                          return { ...hospital, distance }
                        })

                        setFilteredHospitals(hospitalsWithDistance)
                      },
                      (error) => {
                        setLocationError("Unable to access your location. Please enable location services.")
                        setLocation("Location access denied")
                      },
                    )
                  }
                }}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Update Location
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by hospital, doctor, disease, or specialty..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 border-blue-200 focus:border-blue-400"
                  />
                </div>
              </div>

              <Select value={cityFilter} onValueChange={setCityFilter}>
                <SelectTrigger className="border-blue-200 focus:border-blue-400">
                  <MapPin className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Filter by city" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  <SelectItem value="Warangal">Warangal</SelectItem>
                  <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                  <SelectItem value="Karimnagar">Karimnagar</SelectItem>
                  <SelectItem value="Nizamabad">Nizamabad</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="border-blue-200 focus:border-blue-400">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Hospitals</SelectItem>
                  <SelectItem value="emergency">Emergency Only</SelectItem>
                  <SelectItem value="specialty">Specialty Centers</SelectItem>
                  <SelectItem value="general">General Medicine</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results Summary */}
        <div className="mb-4">
          <p className="text-gray-600">
            Found {filteredHospitals.length} hospital{filteredHospitals.length !== 1 ? "s" : ""}
            {searchQuery && ` matching "${searchQuery}"`}
            {cityFilter !== "all" && ` in ${cityFilter}`}
          </p>
        </div>

        {/* Hospitals List */}
        <div className="space-y-4">
          {filteredHospitals.map((hospital) => (
            <Card key={hospital.id} className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-blue-900 text-xl">{hospital.name}</CardTitle>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{hospital.distance} km</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span>{hospital.rating}</span>
                      </div>
                      {hospital.emergency && (
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium">
                          24/7 Emergency
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                    onClick={() => getDirections(hospital)}
                  >
                    <Navigation className="w-4 h-4 mr-1" />
                    Directions
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 text-gray-700">
                    <MapPin className="w-4 h-4" />
                    <span>{hospital.address}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-gray-700">
                    <Phone className="w-4 h-4" />
                    <span>{hospital.phone}</span>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600 mb-2">Specialties:</p>
                    <div className="flex flex-wrap gap-2">
                      {hospital.specialties.map((specialty, index) => (
                        <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600 mb-2">Available Doctors:</p>
                    <div className="flex flex-wrap gap-2">
                      {hospital.doctors.map((doctor, index) => (
                        <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">
                          {doctor}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2 pt-2">
                    <Button variant="outline" className="flex-1 border-blue-200 hover:bg-blue-50">
                      <Phone className="w-4 h-4 mr-2" />
                      Call
                    </Button>
                    <Button variant="outline" className="flex-1 border-blue-200 hover:bg-blue-50">
                      <Clock className="w-4 h-4 mr-2" />
                      Hours
                    </Button>
                    <Link href="/book-appointment" className="flex-1">
                      <Button variant="outline" className="w-full border-blue-200 hover:bg-blue-50">
                        Book Appointment
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredHospitals.length === 0 && (
            <Card className="shadow-lg">
              <CardContent className="text-center py-8">
                <div className="text-gray-500">
                  <MapPin className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No hospitals found matching your search criteria.</p>
                  <p className="text-sm mt-2">Try adjusting your search or filters.</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
