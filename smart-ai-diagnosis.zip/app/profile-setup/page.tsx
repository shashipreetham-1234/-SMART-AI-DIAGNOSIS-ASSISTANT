"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Camera, Upload, User, X } from "lucide-react"
import Link from "next/link"

export default function ProfileSetup() {
  const [profileImage, setProfileImage] = useState<string | null>(null)
  const [showCameraModal, setShowCameraModal] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // ✅ FIXED: Direct camera access
  const openCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      })
      setStream(mediaStream)
      setShowCamera(true)
      setShowCameraModal(false)

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream
          videoRef.current.play()
        }
      }, 100)
    } catch (error) {
      alert("Camera access denied. Please enable camera permissions.")
    }
  }

  // ✅ FIXED: Direct file picker access
  const openFilePicker = () => {
    setShowCameraModal(false)
    fileInputRef.current?.click()
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      const context = canvas.getContext("2d")

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      if (context) {
        context.drawImage(video, 0, 0)
        const imageDataUrl = canvas.toDataURL("image/jpeg")
        setProfileImage(imageDataUrl)
        closeCamera()
      }
    }
  }

  const closeCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setShowCamera(false)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center pb-8">
            <CardTitle className="text-3xl font-bold text-blue-900 mb-2">Profile Setup</CardTitle>
            <p className="text-gray-600">Complete your profile to get personalized health insights</p>
          </CardHeader>

          <CardContent className="space-y-8">
            {/* ✅ FIXED: Profile Picture Upload */}
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-100 to-cyan-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
                  {profileImage ? (
                    <img
                      src={profileImage || "/placeholder.svg"}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="w-16 h-16 text-blue-400" />
                  )}
                </div>

                {/* ✅ FIXED: Camera button that actually works */}
                <button
                  type="button"
                  onClick={() => setShowCameraModal(true)}
                  className="absolute -bottom-2 -right-2 w-10 h-10 bg-cyan-600 rounded-full flex items-center justify-center shadow-lg hover:bg-cyan-700 transition-all duration-300 hover:scale-110"
                >
                  <Camera className="w-5 h-5 text-white" />
                </button>
              </div>
              <p className="text-sm text-gray-600 text-center">Click the camera icon to upload your profile picture</p>
            </div>

            {/* ✅ FIXED: Hidden file input */}
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />

            {/* ✅ FIXED: Camera options modal */}
            {showCameraModal && (
              <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
                  <h3 className="text-lg font-semibold mb-4">Add Profile Picture</h3>
                  <div className="space-y-3">
                    <Button
                      onClick={openCamera}
                      className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center"
                    >
                      <Camera className="w-5 h-5 mr-2" />📷 Take Photo
                    </Button>
                    <Button
                      onClick={openFilePicker}
                      className="w-full h-12 bg-green-600 hover:bg-green-700 text-white flex items-center justify-center"
                    >
                      <Upload className="w-5 h-5 mr-2" />📁 Choose File
                    </Button>
                    <Button onClick={() => setShowCameraModal(false)} variant="outline" className="w-full">
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* ✅ FIXED: Camera modal */}
            {showCamera && (
              <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Take Photo</h3>
                    <Button variant="ghost" size="sm" onClick={closeCamera}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="space-y-4">
                    <video
                      ref={videoRef}
                      className="w-full h-64 bg-black rounded-lg object-cover"
                      autoPlay
                      playsInline
                      muted
                    />
                    <div className="flex space-x-2">
                      <Button onClick={capturePhoto} className="flex-1 bg-blue-600 hover:bg-blue-700">
                        📷 Capture
                      </Button>
                      <Button onClick={closeCamera} variant="outline" className="flex-1">
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <canvas ref={canvasRef} className="hidden" />

            {/* Rest of the form fields remain the same */}
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-blue-900 font-medium">
                  Full Name
                </Label>
                <Input
                  id="name"
                  placeholder="Enter your full name"
                  className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-blue-900 font-medium">Age</Label>
                  <Input
                    type="number"
                    placeholder="Age"
                    className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-blue-900 font-medium">Blood Group</Label>
                  <Select>
                    <SelectTrigger className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a+">A+</SelectItem>
                      <SelectItem value="a-">A-</SelectItem>
                      <SelectItem value="b+">B+</SelectItem>
                      <SelectItem value="b-">B-</SelectItem>
                      <SelectItem value="ab+">AB+</SelectItem>
                      <SelectItem value="ab-">AB-</SelectItem>
                      <SelectItem value="o+">O+</SelectItem>
                      <SelectItem value="o-">O-</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-blue-900 font-medium">Weight (kg)</Label>
                  <Input
                    type="number"
                    placeholder="Weight"
                    className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-blue-900 font-medium">Medical History</Label>
                <Textarea
                  placeholder="Describe any past medical conditions, surgeries, or ongoing treatments..."
                  className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300 min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-blue-900 font-medium">Allergies</Label>
                <Textarea
                  placeholder="List any known allergies to medications, foods, or environmental factors..."
                  className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300 min-h-[80px]"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-blue-900 font-medium">Location</Label>
                <Select>
                  <SelectTrigger className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300">
                    <SelectValue placeholder="Select your city" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warangal">Warangal</SelectItem>
                    <SelectItem value="hyderabad">Hyderabad</SelectItem>
                    <SelectItem value="karimnagar">Karimnagar</SelectItem>
                    <SelectItem value="nizamabad">Nizamabad</SelectItem>
                    <SelectItem value="khammam">Khammam</SelectItem>
                    <SelectItem value="adilabad">Adilabad</SelectItem>
                    <SelectItem value="nalgonda">Nalgonda</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-blue-900 font-medium">Current Medications</Label>
                  <RadioGroup defaultValue="no" className="flex space-x-6">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="med-yes" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="med-yes" className="text-gray-700">
                        Yes
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="med-no" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="med-no" className="text-gray-700">
                        No
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="occasionally" id="med-occ" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="med-occ" className="text-gray-700">
                        Occasionally
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-900 font-medium">Smoking</Label>
                  <RadioGroup defaultValue="no" className="flex space-x-6">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="smoke-yes" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="smoke-yes" className="text-gray-700">
                        Yes
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="smoke-no" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="smoke-no" className="text-gray-700">
                        No
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="occasionally" id="smoke-occ" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="smoke-occ" className="text-gray-700">
                        Occasionally
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-900 font-medium">Alcohol</Label>
                  <RadioGroup defaultValue="no" className="flex space-x-6">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="alcohol-yes" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="alcohol-yes" className="text-gray-700">
                        Yes
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="alcohol-no" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="alcohol-no" className="text-gray-700">
                        No
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="occasionally" id="alcohol-occ" className="border-blue-400 text-blue-600" />
                      <Label htmlFor="alcohol-occ" className="text-gray-700">
                        Occasionally
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              <div className="space-y-4">
                <Label className="text-blue-900 font-medium text-lg">Emergency Contact</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-blue-900 font-medium">Name</Label>
                    <Input
                      placeholder="Emergency contact name"
                      className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-blue-900 font-medium">Phone Number</Label>
                    <Input
                      placeholder="Emergency contact phone"
                      className="border-blue-200 focus:border-blue-400 focus:ring-blue-400 hover:border-blue-300 transition-all duration-300"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <Link href="/dashboard">
                <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-semibold py-4 text-lg transition-all duration-300 hover:shadow-[0_0_30px_rgba(34,211,238,0.5)] hover:scale-105">
                  Next
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
