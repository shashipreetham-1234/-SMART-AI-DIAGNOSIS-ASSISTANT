"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Mic, Camera, Send, MapPin, Star, Phone, X, ImageIcon } from "lucide-react"
import Link from "next/link"

// Enhanced skin disease detection database
const skinDiseaseDatabase = {
  eczema: {
    disease: "Eczema",
    confidence: 85,
    specialty: "Dermatology",
    description:
      "A chronic inflammatory skin condition causing dry, itchy, and red skin. Common in skin folds and often flares up periodically.",
    recommendation:
      "Use moisturizers regularly, avoid triggers, and consult a dermatologist for prescription treatments if severe.",
  },
  acne: {
    disease: "Acne",
    confidence: 92,
    specialty: "Dermatology",
    description:
      "A skin condition with pimples, blackheads, and cysts caused by clogged hair follicles with oil and dead skin cells.",
    recommendation:
      "Wash affected areas with gentle cleanser, use over-the-counter benzoyl peroxide products, and see a dermatologist for severe cases.",
  },
  psoriasis: {
    disease: "Psoriasis",
    confidence: 88,
    specialty: "Dermatology",
    description:
      "An autoimmune condition causing rapid skin cell growth, resulting in thick, red patches with silvery scales.",
    recommendation:
      "Moisturize regularly, avoid triggers like stress, and consult a dermatologist for prescription treatments.",
  },
  dermatitis: {
    disease: "Contact Dermatitis",
    confidence: 80,
    specialty: "Dermatology",
    description:
      "Skin inflammation caused by direct contact with an irritant or allergen, resulting in redness, itching, and sometimes blisters.",
    recommendation:
      "Identify and avoid the trigger, use cool compresses, and apply over-the-counter hydrocortisone cream for mild cases.",
  },
  rosacea: {
    disease: "Rosacea",
    confidence: 75,
    specialty: "Dermatology",
    description:
      "A chronic inflammatory skin condition causing facial redness, visible blood vessels, and sometimes small red bumps.",
    recommendation:
      "Avoid triggers like spicy food and alcohol, use gentle skincare products, and see a dermatologist for prescription treatments.",
  },
  ringworm: {
    disease: "Ringworm (Tinea)",
    confidence: 82,
    specialty: "Dermatology",
    description:
      "A fungal infection causing a circular, red, itchy patch with clearer skin in the center, giving a ring-like appearance.",
    recommendation:
      "Apply over-the-counter antifungal creams, keep the area clean and dry, and see a doctor if it doesn't improve in 2 weeks.",
  },
  impetigo: {
    disease: "Impetigo",
    confidence: 78,
    specialty: "Dermatology",
    description:
      "A highly contagious bacterial skin infection causing red sores that quickly rupture, ooze, and form a honey-colored crust.",
    recommendation:
      "See a doctor promptly for antibiotic treatment, keep sores clean, and avoid touching or sharing items with affected areas.",
  },
  melanoma: {
    disease: "Possible Melanoma",
    confidence: 70,
    specialty: "Dermatology",
    description:
      "A serious form of skin cancer that develops from pigment-producing cells. Early detection is critical.",
    recommendation: "Seek immediate medical attention from a dermatologist for proper diagnosis and treatment.",
  },
}

// Telangana doctor database with focus on Warangal
const doctorDatabase = [
  {
    id: 1,
    name: "Dr. Rajesh Kumar",
    specialty: "Internal Medicine",
    city: "Warangal",
    hospital: "MGM Hospital",
    rating: 4.8,
    experience: "15 years",
    availability: "Available Today",
    phone: "+91 9876543210",
  },
  {
    id: 2,
    name: "Dr. Srinivas Rao",
    specialty: "Dermatology",
    city: "Warangal",
    hospital: "Lifeline Hospital",
    rating: 4.8,
    experience: "12 years",
    availability: "Available Today",
    phone: "+91 9876543216",
  },
  {
    id: 3,
    name: "Dr. Sudha Rani",
    specialty: "Dermatology",
    city: "Hyderabad",
    hospital: "KIMS Hospital",
    rating: 4.8,
    experience: "15 years",
    availability: "Available Next Week",
    phone: "+91 9876543219",
  },
]

export default function SymptomChecker() {
  const [symptoms, setSymptoms] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<any>(null)
  const [recommendedDoctors, setRecommendedDoctors] = useState<any[]>([])
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isSkinAnalysis, setIsSkinAnalysis] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)

  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // ✅ FIXED: Direct camera access
  const openCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }, // Back camera for medical photos
        audio: false,
      })

      setStream(mediaStream)
      setShowCamera(true)

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream
          videoRef.current.play()
        }
      }, 100)
    } catch (error) {
      console.error("Error accessing camera:", error)
      alert("Unable to access camera. Please check permissions and try again.")
    }
  }

  // ✅ FIXED: Direct file picker access
  const openFilePicker = () => {
    fileInputRef.current?.click()
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      const context = canvas.getContext("2d")

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      if (context) {
        context.drawImage(video, 0, 0)
        const imageDataUrl = canvas.toDataURL("image/jpeg")
        setSelectedImage(imageDataUrl)
        setSymptoms("") // Clear text symptoms when image is selected
        closeCamera()

        // Automatically analyze the image
        setTimeout(() => {
          analyzeImage(imageDataUrl)
        }, 500)
      }
    }
  }

  const closeCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setShowCamera(false)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string
        setSelectedImage(imageUrl)
        setSymptoms("") // Clear text symptoms when image is selected

        // Automatically analyze the image
        setTimeout(() => {
          analyzeImage(imageUrl)
        }, 500)
      }
      reader.readAsDataURL(file)
    }
  }

  // ✅ FIXED: Analyze image function
  const analyzeImage = (imageUrl: string) => {
    setIsAnalyzing(true)
    setIsSkinAnalysis(true)

    // Simulate AI processing delay
    setTimeout(() => {
      // Get a random skin disease for demo purposes
      const skinDiseases = Object.values(skinDiseaseDatabase)
      const randomIndex = Math.floor(Math.random() * skinDiseases.length)
      const detectedDisease = skinDiseases[randomIndex]

      // Add additional analysis details
      const result = {
        ...detectedDisease,
        analysisDetails: {
          imageQuality: "Good",
          skinArea: "Detected",
          riskLevel: detectedDisease.disease.includes("Melanoma") ? "High" : "Low",
        },
      }

      setAnalysis(result)

      // Find doctors based on specialty and location (prioritize Warangal)
      const doctors = doctorDatabase
        .filter((doc) => doc.specialty === detectedDisease.specialty)
        .sort((a, b) => {
          // Prioritize Warangal doctors
          if (a.city === "Warangal" && b.city !== "Warangal") return -1
          if (a.city !== "Warangal" && b.city === "Warangal") return 1
          // Then sort by rating
          return b.rating - a.rating
        })

      setRecommendedDoctors(doctors)
      setIsAnalyzing(false)
    }, 3000)
  }

  const analyzeSymptoms = async () => {
    if ((!symptoms.trim() && !selectedImage) || isAnalyzing) return

    setIsAnalyzing(true)

    // Simulate AI processing delay
    await new Promise((resolve) => setTimeout(resolve, 3000))

    // For text-based symptoms, use the existing logic
    if (symptoms.trim()) {
      setIsSkinAnalysis(false)
      // Simple symptom matching logic (would be replaced by actual AI)
      const result = {
        disease: "Common Cold",
        confidence: 75,
        specialty: "General Practice",
        description: "A viral infection of the upper respiratory tract causing runny nose, sore throat, and cough.",
        recommendation:
          "Rest, stay hydrated, and take over-the-counter cold medications if needed. See a doctor if symptoms worsen or last more than 10 days.",
      }

      setAnalysis(result)
      setRecommendedDoctors(doctorDatabase.filter((doc) => doc.specialty === "Internal Medicine"))
    }

    setIsAnalyzing(false)
  }

  const handleVoiceInput = () => {
    if (!isRecording) {
      setIsRecording(true)

      // Check if browser supports speech recognition
      if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
        const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition
        const recognition = new SpeechRecognition()

        recognition.continuous = false
        recognition.interimResults = false
        recognition.lang = "en-US"

        recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript
          setSymptoms(transcript)
          setIsRecording(false)
        }

        recognition.onerror = () => {
          setIsRecording(false)
          alert("Voice recognition failed. Please try again.")
        }

        recognition.onend = () => {
          setIsRecording(false)
        }

        recognition.start()
      } else {
        // Fallback simulation for browsers without speech recognition
        setTimeout(() => {
          setSymptoms("I have been experiencing fever and headache for the past two days")
          setIsRecording(false)
        }, 3000)
      }
    } else {
      setIsRecording(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">AI Symptom Checker</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">Describe Your Symptoms or Upload an Image</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedImage ? (
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={selectedImage || "/placeholder.svg"}
                      alt="Uploaded skin condition"
                      className="w-full h-64 object-contain rounded-lg border border-blue-200"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      className="absolute top-2 right-2 bg-white/80"
                      onClick={() => setSelectedImage(null)}
                    >
                      Remove
                    </Button>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                    <p className="text-sm text-green-800">
                      ✓ Image uploaded successfully. Our AI will analyze this skin condition and provide a diagnosis.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="symptoms">What symptoms are you experiencing?</Label>
                  <Textarea
                    id="symptoms"
                    placeholder="Describe your symptoms in detail... (e.g., fever, headache, nausea, skin rash)"
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    className="min-h-[120px] border-blue-200 focus:border-blue-400"
                  />
                </div>
              )}

              {/* ✅ FIXED: Input Options */}
              <div className="flex flex-col space-y-3">
                {/* Text input options */}
                {!selectedImage && (
                  <Button variant="outline" className="border-blue-200 hover:bg-blue-50" onClick={handleVoiceInput}>
                    <Mic className={`w-4 h-4 mr-2 ${isRecording ? "text-red-500 animate-pulse" : ""}`} />
                    {isRecording ? "Recording..." : "Voice Input"}
                  </Button>
                )}

                {/* ✅ FIXED: Image upload options */}
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={openCamera}
                    className="bg-blue-600 hover:bg-blue-700 active:scale-95 transition-transform"
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Take Photo
                  </Button>
                  <Button
                    onClick={openFilePicker}
                    className="bg-green-600 hover:bg-green-700 active:scale-95 transition-transform"
                  >
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Upload Image
                  </Button>
                </div>

                {/* Hidden file input */}
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </div>

              {symptoms && !selectedImage && (
                <Button
                  onClick={analyzeSymptoms}
                  disabled={isAnalyzing || !symptoms.trim()}
                  className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                >
                  <Send className="w-4 h-4 mr-2" />
                  {isAnalyzing ? "Analyzing..." : "Analyze Symptoms"}
                </Button>
              )}
            </CardContent>
          </Card>

          {/* AI Analysis Results */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">AI Analysis Results</CardTitle>
            </CardHeader>
            <CardContent>
              {isAnalyzing ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <div className="text-2xl">🤖</div>
                  </div>
                  <p className="text-gray-600">
                    AI is analyzing your {isSkinAnalysis ? "skin condition image" : "symptoms"}...
                  </p>
                  {isSkinAnalysis && (
                    <p className="text-sm text-blue-600 mt-2">
                      Using advanced computer vision for skin disease detection
                    </p>
                  )}
                </div>
              ) : analysis ? (
                <div className="space-y-4">
                  <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                    <h3 className="font-bold text-blue-900 text-lg mb-2">
                      {isSkinAnalysis ? "Detected Skin Condition" : "Most Likely Condition"}
                    </h3>
                    <p className="text-xl font-semibold text-gray-800">{analysis.disease}</p>
                    <p className="text-sm text-gray-600 mt-1">
                      Confidence: {analysis.confidence}% | Specialty: {analysis.specialty}
                    </p>
                    {analysis.description && <p className="text-sm text-gray-700 mt-2">{analysis.description}</p>}
                  </div>

                  {/* Recommendation */}
                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <h4 className="font-medium text-green-900 mb-2">Recommendation</h4>
                    <p className="text-sm text-green-800">{analysis.recommendation}</p>
                  </div>

                  {/* Enhanced analysis for skin conditions */}
                  {isSkinAnalysis && analysis.analysisDetails && (
                    <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                      <h4 className="font-medium text-blue-900 mb-2">Analysis Details</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          Image Quality: <span className="font-medium">{analysis.analysisDetails.imageQuality}</span>
                        </div>
                        <div>
                          Skin Area: <span className="font-medium">{analysis.analysisDetails.skinArea}</span>
                        </div>
                        <div>
                          Risk Level:{" "}
                          <span
                            className={`font-medium ${analysis.analysisDetails.riskLevel === "High" ? "text-red-600" : "text-green-600"}`}
                          >
                            {analysis.analysisDetails.riskLevel}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
                    <p className="text-sm text-yellow-800">
                      <strong>Disclaimer:</strong> This is an AI-generated suggestion based on{" "}
                      {isSkinAnalysis ? "image analysis" : "your symptoms"}. Please consult with a qualified healthcare
                      professional for proper diagnosis and treatment.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="text-2xl">🤖</div>
                  </div>
                  <p>Enter your symptoms or upload a skin condition image to get AI-powered analysis.</p>
                  <p className="text-sm mt-2 text-blue-600">
                    Our AI can detect various skin conditions including eczema, acne, psoriasis, ringworm, and more.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ✅ FIXED: Camera modal */}
        {showCamera && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Take Photo of Skin Condition</h3>
                <Button variant="ghost" size="sm" onClick={closeCamera}>
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <video
                  ref={videoRef}
                  className="w-full h-64 bg-black rounded-lg object-cover"
                  autoPlay
                  playsInline
                  muted
                />

                <div className="flex space-x-2">
                  <Button onClick={capturePhoto} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    📷 Capture Photo
                  </Button>
                  <Button onClick={closeCamera} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Hidden canvas for photo capture */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Recommended Doctors */}
        {recommendedDoctors.length > 0 && (
          <Card className="shadow-lg mt-6">
            <CardHeader>
              <CardTitle className="text-blue-900">Recommended Doctors in Telangana</CardTitle>
              <p className="text-gray-600">Based on your condition and location (Warangal priority)</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendedDoctors.slice(0, 4).map((doctor) => (
                  <div
                    key={doctor.id}
                    className="bg-white rounded-lg p-4 border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-bold text-gray-800">{doctor.name}</h3>
                        <p className="text-blue-600 text-sm">{doctor.specialty}</p>
                        <p className="text-gray-600 text-sm">{doctor.hospital}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm font-medium">{doctor.rating}</span>
                        </div>
                        <p className="text-xs text-gray-500">{doctor.experience}</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-3 h-3" />
                        <span>{doctor.city}</span>
                        {doctor.city === "Warangal" && (
                          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Local</span>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            doctor.availability.includes("Today")
                              ? "bg-green-100 text-green-800"
                              : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {doctor.availability}
                        </span>
                      </div>
                    </div>

                    <div className="flex space-x-2 mt-4">
                      <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                        <Phone className="w-3 h-3 mr-1" />
                        Call
                      </Button>
                      <Link href="/book-appointment" className="flex-1">
                        <Button size="sm" variant="outline" className="w-full">
                          Book Appointment
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
