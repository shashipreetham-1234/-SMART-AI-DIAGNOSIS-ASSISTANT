"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Upload, Camera, FileText, Eye, Download, Trash2, X } from "lucide-react"
import Link from "next/link"

interface UploadedReport {
  id: number
  name: string
  type: string
  date: string
  size: string
  extractedText?: string
  category: string
  imageUrl?: string
}

export default function UploadReports() {
  const [uploadedReports, setUploadedReports] = useState<UploadedReport[]>([
    {
      id: 1,
      name: "Blood Test Results",
      type: "PDF",
      date: "2024-01-15",
      size: "2.3 MB",
      extractedText:
        "Hemoglobin: 14.2 g/dL (Normal)\nWhite Blood Cells: 7,200/μL (Normal)\nPlatelets: 250,000/μL (Normal)",
      category: "Lab Results",
    },
    {
      id: 2,
      name: "X-Ray Chest",
      type: "Image",
      date: "2024-01-10",
      size: "1.8 MB",
      extractedText: "No acute cardiopulmonary abnormalities detected. Heart size normal. Lung fields clear.",
      category: "Imaging",
    },
  ])

  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [extractedText, setExtractedText] = useState("")
  const [reportCategory, setReportCategory] = useState("")
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)

  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // ✅ FIXED: Direct camera access
  const openCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      })
      setStream(mediaStream)
      setShowCamera(true)
      setShowUploadModal(false)

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream
          videoRef.current.play()
        }
      }, 100)
    } catch (error) {
      alert("Camera access denied. Please enable camera permissions.")
    }
  }

  // ✅ FIXED: Direct file picker access
  const openFilePicker = () => {
    setShowUploadModal(false)
    fileInputRef.current?.click()
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      const context = canvas.getContext("2d")

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      if (context) {
        context.drawImage(video, 0, 0)
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], `medical-report-${Date.now()}.jpg`, { type: "image/jpeg" })
            setSelectedFile(file)
            simulateOCR(file)
            closeCamera()
          }
        }, "image/jpeg")
      }
    }
  }

  const closeCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setShowCamera(false)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        alert("File size must be less than 10MB")
        return
      }
      setSelectedFile(file)
      simulateOCR(file)
    }
  }

  const simulateOCR = async (file: File) => {
    setIsProcessing(true)
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const mockExtractedText = file.type.includes("image")
      ? "Medical Report\nPatient: John Doe\nDate: January 20, 2024\nFindings: Normal examination results\nRecommendations: Continue current treatment"
      : "Lab Report\nTest Date: January 20, 2024\nGlucose: 95 mg/dL (Normal)\nCholesterol: 180 mg/dL (Normal)\nBlood Pressure: 120/80 mmHg"

    setExtractedText(mockExtractedText)
    setIsProcessing(false)
  }

  const saveReport = () => {
    if (selectedFile) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const newReport: UploadedReport = {
          id: Date.now(),
          name: selectedFile.name,
          type: selectedFile.type.includes("image") ? "Image" : "PDF",
          date: new Date().toISOString().split("T")[0],
          size: `${(selectedFile.size / 1024 / 1024).toFixed(1)} MB`,
          extractedText: extractedText,
          category: reportCategory || "General",
          imageUrl: selectedFile.type.includes("image") ? (e.target?.result as string) : undefined,
        }

        setUploadedReports([newReport, ...uploadedReports])
        setSelectedFile(null)
        setExtractedText("")
        setReportCategory("")
      }

      if (selectedFile.type.includes("image")) {
        reader.readAsDataURL(selectedFile)
      } else {
        const newReport: UploadedReport = {
          id: Date.now(),
          name: selectedFile.name,
          type: "PDF",
          date: new Date().toISOString().split("T")[0],
          size: `${(selectedFile.size / 1024 / 1024).toFixed(1)} MB`,
          extractedText: extractedText,
          category: reportCategory || "General",
        }

        setUploadedReports([newReport, ...uploadedReports])
        setSelectedFile(null)
        setExtractedText("")
        setReportCategory("")
      }
    }
  }

  const deleteReport = (id: number) => {
    setUploadedReports(uploadedReports.filter((report) => report.id !== id))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center mb-6">
          <Link href="/dashboard">
            <Button variant="ghost" className="mr-4 hover:bg-blue-100">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-blue-900">Upload Medical Reports</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">Upload New Report</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Report Category</Label>
                <Input
                  placeholder="e.g., Lab Results, X-Ray, Prescription"
                  value={reportCategory}
                  onChange={(e) => setReportCategory(e.target.value)}
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              {/* ✅ FIXED: Upload area */}
              <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                    <Upload className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-700">Upload your medical reports</p>
                    <p className="text-sm text-gray-500">Supports PDF, JPG, PNG files up to 10MB</p>
                  </div>
                  <div className="flex space-x-4 justify-center">
                    {/* ✅ FIXED: Upload button that actually works */}
                    <Button
                      onClick={() => setShowUploadModal(true)}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Report
                    </Button>
                  </div>
                </div>
              </div>

              {selectedFile && (
                <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                  <div className="flex items-center space-x-3">
                    <FileText className="w-8 h-8 text-blue-600" />
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">{selectedFile.name}</p>
                      <p className="text-sm text-gray-600">{(selectedFile.size / 1024 / 1024).toFixed(1)} MB</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900">AI Text Extraction (OCR)</CardTitle>
            </CardHeader>
            <CardContent>
              {isProcessing ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <FileText className="w-8 h-8 text-blue-600" />
                  </div>
                  <p className="text-gray-600">Processing document with AI...</p>
                </div>
              ) : extractedText ? (
                <div className="space-y-4">
                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <p className="text-sm text-green-800 mb-2">✓ Text successfully extracted</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Extracted Text</Label>
                    <Textarea
                      value={extractedText}
                      onChange={(e) => setExtractedText(e.target.value)}
                      className="min-h-[200px] border-blue-200 focus:border-blue-400"
                      placeholder="Extracted text will appear here..."
                    />
                  </div>
                  <Button
                    onClick={saveReport}
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                  >
                    Save Report
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p>Upload a document to extract text using AI</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ✅ FIXED: Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
          onChange={handleFileUpload}
          className="hidden"
        />

        {/* ✅ FIXED: Upload options modal */}
        {showUploadModal && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
              <h3 className="text-lg font-semibold mb-4">Upload Medical Report</h3>
              <div className="space-y-3">
                <Button
                  onClick={openCamera}
                  className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center"
                >
                  <Camera className="w-5 h-5 mr-2" />📷 Take Photo
                </Button>
                <Button
                  onClick={openFilePicker}
                  className="w-full h-12 bg-green-600 hover:bg-green-700 text-white flex items-center justify-center"
                >
                  <Upload className="w-5 h-5 mr-2" />📁 Choose File
                </Button>
                <Button onClick={() => setShowUploadModal(false)} variant="outline" className="w-full">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ✅ FIXED: Camera modal */}
        {showCamera && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Take Photo of Medical Report</h3>
                <Button variant="ghost" size="sm" onClick={closeCamera}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="space-y-4">
                <video
                  ref={videoRef}
                  className="w-full h-64 bg-black rounded-lg object-cover"
                  autoPlay
                  playsInline
                  muted
                />
                <div className="flex space-x-2">
                  <Button onClick={capturePhoto} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    📷 Capture
                  </Button>
                  <Button onClick={closeCamera} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />

        {/* Saved Reports */}
        <Card className="shadow-lg mt-6">
          <CardHeader>
            <CardTitle className="text-blue-900">Your Health Records</CardTitle>
            <p className="text-gray-600">All your uploaded medical documents</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {uploadedReports.map((report) => (
                <div
                  key={report.id}
                  className="bg-white rounded-lg p-4 border border-gray-200 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-800">{report.name}</h3>
                        <div className="flex items-center space-x-4 mt-1 text-sm text-gray-600">
                          <span>{report.type}</span>
                          <span>{report.date}</span>
                          <span>{report.size}</span>
                          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                            {report.category}
                          </span>
                        </div>
                        {report.imageUrl && (
                          <img
                            src={report.imageUrl || "/placeholder.svg"}
                            alt="Medical report"
                            className="w-32 h-32 object-cover rounded mt-2"
                          />
                        )}
                        {report.extractedText && (
                          <div className="mt-2 p-2 bg-gray-50 rounded text-sm text-gray-700">
                            <p className="line-clamp-2">{report.extractedText}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" className="border-blue-200 hover:bg-blue-50">
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button size="sm" variant="outline" className="border-blue-200 hover:bg-blue-50">
                        <Download className="w-3 h-3 mr-1" />
                        Download
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteReport(report.id)}
                        className="border-red-200 hover:bg-red-50 text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
